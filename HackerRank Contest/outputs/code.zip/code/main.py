"""Deterministic Buy-or-Wait financial planning agent.

Run from the repository root: python code/main.py
No API key is required.  The program reconstructs a conservative cash-flow
forecast, tests each eligible payment option, and verifies every selected plan.
"""
from __future__ import annotations

import csv
import itertools
import re
import statistics
import subprocess
import sys
from collections import defaultdict
from datetime import date, datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "dataset"
OUT_COLUMNS = ["request_id", "amount_safe_to_pay", "affordability_status",
               "recommended_payment_method", "payment_plan",
               "earliest_date_for_full_payment", "spending_changes_needed",
               "decision_explanation"]
ZERO = Decimal("0")


def read_csv(name: str) -> list[dict[str, str]]:
    with (DATA / name).open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def money(value: str | Decimal) -> Decimal:
    if value is None or str(value).strip() == "":
        return ZERO
    return Decimal(str(value).replace(",", "").strip())


def d(value: str) -> date:
    return datetime.strptime(value[:10], "%Y-%m-%d").date()


def fmt(amount: Decimal) -> str:
    """Use at most two decimal places, without a needless .00."""
    q = amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return format(q, "f").rstrip("0").rstrip(".") if "." in format(q, "f") else format(q, "f")


def split(value: str) -> set[str]:
    return {x.strip() for x in (value or "").split("|") if x.strip()}


class Agent:
    def __init__(self) -> None:
        self.profiles = {r["user_id"]: r for r in read_csv("financial_profiles.csv")}
        self.events = read_csv("financial_events.csv")
        self.options = read_csv("request_payment_options.csv")
        self.messages = read_csv("messages.csv")
        self.images = read_csv("images.csv")
        # OCR is expensive. Cache both successful reads and misses so one image-only
        # event is never sent to Tesseract again during the many plan simulations.
        self.ocr_cache: dict[str, Decimal | None] = {}
        self.rates = {(r["rate_date"], r["from_currency"], r["to_currency"]): money(r["rate"])
                      for r in read_csv("exchange_rates.csv")}
        self.by_user: dict[str, list[dict[str, str]]] = defaultdict(list)
        self.by_request_options: dict[str, list[dict[str, str]]] = defaultdict(list)
        for event in self.events:
            self.by_user[event["user_id"]].append(event)
        for option in self.options:
            self.by_request_options[option["request_id"]].append(option)

    def converted_amount(self, event: dict[str, str], home: str) -> Decimal | None:
        raw = event.get("amount", "")
        if not raw.strip():
            # A blank amount is evidence to inspect, not a zero-dollar transaction.
            return self.ocr_amount(event, home)
        amount = money(raw)
        currency = event.get("currency", home)
        if currency == home:
            return amount
        when = event.get("settlement_date") or event.get("event_date")
        rate = self.rates.get((when, currency, home))
        return amount * rate if rate is not None else None

    def ocr_amount(self, event: dict[str, str], home: str) -> Decimal | None:
        """Best-effort local OCR for the handful of image-only financial events."""
        event_id = event["event_id"]
        if event_id in self.ocr_cache:
            return self.ocr_cache[event_id]
        matches = [x for x in self.images if x.get("related_event_id") == event_id]
        if not matches:
            self.ocr_cache[event_id] = None
            return None
        image = DATA / "media" / "images" / f"{matches[0]['image_id']}.png"
        try:
            text = subprocess.run(["tesseract", str(image), "stdout"], capture_output=True,
                                  text=True, timeout=20, check=False).stdout
        except (FileNotFoundError, subprocess.TimeoutExpired):
            self.ocr_cache[event_id] = None
            return None
        # Prefer numbers adjacent to a recognised currency code; do not guess from arbitrary text.
        code = re.escape(event.get("currency") or home)
        found = re.search(rf"{code}\s*([0-9][0-9,]*(?:\.\d{{1,2}})?)", text, re.I)
        self.ocr_cache[event_id] = money(found.group(1)) if found else None
        return self.ocr_cache[event_id]

    def relevant_events(self, user_id: str, as_of: date, home: str) -> list[dict[str, object]]:
        """Normalize cash events and remove failed/cancelled records and cancelled originals."""
        raw = self.by_user[user_id]
        cancelled_links = {e.get("linked_event_id") for e in raw
                           if e.get("status") in {"cancelled", "failed"} and e.get("linked_event_id")}
        result = []
        for e in raw:
            if e.get("event_id") in cancelled_links or e.get("status") in {"cancelled", "failed", "unrealized"}:
                continue
            amount = self.converted_amount(e, home)
            if amount is None:
                continue
            settle = d(e.get("settlement_date") or e["event_date"])
            # Pending credits and refunds are deliberately excluded until actually settled.
            if e.get("status") == "pending" and e.get("direction") == "credit":
                continue
            if e.get("event_type") == "investment_valuation":
                continue
            result.append({"id": e["event_id"], "date": settle, "amount": amount,
                           "direction": e["direction"], "category": e.get("category", ""),
                           "description": e.get("description", ""), "status": e.get("status"),
                           "flexibility": e.get("flexibility", "fixed"),
                           "minimum": money(e.get("minimum_allowed_amount", ""))})
        return result

    def forecast(self, user_id: str, start: date, days: int, changes: list[tuple[str, Decimal, str, Decimal]] | None = None) -> tuple[dict[date, Decimal], list[dict[str, object]]]:
        profile = self.profiles[user_id]
        home = profile["home_currency"]
        events = self.relevant_events(user_id, start, home)
        end = start + timedelta(days=days)
        flows: dict[date, Decimal] = defaultdict(lambda: ZERO)
        future_dates: set[tuple[str, str, date]] = set()
        for e in events:
            eday = e["date"]
            if start <= eday <= end and e["status"] in {"pending", "scheduled", "settled"}:
                signed = e["amount"] if e["direction"] == "credit" else -e["amount"]
                flows[eday] += signed
                future_dates.add((str(e["category"]), str(e["direction"]), eday))

        # Learn repeating cash flows from history by category and direction. Synthetic data uses
        # stable category cadences even when merchant descriptions vary from week to week.
        groups: dict[tuple[str, str], list[dict[str, object]]] = defaultdict(list)
        for e in events:
            if e["date"] < start and e["status"] == "settled":
                groups[(str(e["category"]), str(e["direction"]))].append(e)
        for (category, direction), hist in groups.items():
            hist.sort(key=lambda x: x["date"])
            recent = [x for x in hist if x["date"] >= start - timedelta(days=150)]
            # Two dated observations are enough for a fixed monthly bill.  Requiring
            # three would incorrectly drop a newly confirmed salary/bill from the forecast.
            if len(recent) < 2:
                continue
            dates = [x["date"] for x in recent]
            gaps = [(b - a).days for a, b in zip(dates, dates[1:]) if 1 <= (b-a).days <= 45]
            if len(gaps) < 1:
                continue
            interval = int(round(statistics.median(gaps)))
            if interval < 2 or interval > 40:
                continue
            # Variable categories are represented by all spending in that category; a median is
            # more robust than one unusually large grocery or fuel transaction.
            sample = recent[-min(8, len(recent)):]
            amount = Decimal(str(statistics.median([float(x["amount"]) for x in sample])))
            last = dates[-1]
            nxt = last + timedelta(days=interval)
            while nxt <= end:
                if not any(abs((nxt - fd).days) <= 2 for c, dr, fd in future_dates if c == category and dr == direction):
                    signed = amount if direction == "credit" else -amount
                    flows[nxt] += signed
                nxt += timedelta(days=interval)
        # A supplied "next confirmed salary" is evidence that the established salary
        # cadence continues.  Repeat it monthly after its explicit occurrence; this is
        # intentionally limited to salary income, not speculative credits or bonuses.
        for e in events:
            if (e["category"] != "salary" or e["direction"] != "credit" or
                    e["status"] not in {"scheduled", "settled"} or e["date"] < start):
                continue
            nxt = e["date"] + timedelta(days=30)
            while nxt <= end:
                if ("salary", "credit", nxt) not in future_dates:
                    flows[nxt] += e["amount"]
                nxt += timedelta(days=30)
        # Apply only explicit, profile-authorised flexible changes.  The saving is
        # attached to the observed recurring cadence, never treated as invented income.
        for event_id, amount, action, floor in changes or []:
            source = next((e for e in events if e["id"] == event_id), None)
            if not source:
                continue
            saving = amount if action == "stop" else max(ZERO, amount - floor)
            peers = sorted([e["date"] for e in events if e["category"] == source["category"] and e["direction"] == "debit" and e["date"] < start])
            gaps = [(b-a).days for a, b in zip(peers, peers[1:]) if 1 <= (b-a).days <= 45]
            interval = int(round(statistics.median(gaps))) if gaps else 30
            nxt = source["date"] + timedelta(days=interval)
            while nxt < start:
                nxt += timedelta(days=interval)
            while nxt <= end:
                flows[nxt] += saving
                nxt += timedelta(days=interval)
        return flows, events

    def balances(self, user_id: str, start: date, payments: list[tuple[date, Decimal]], changes: list[tuple[str, Decimal, str, Decimal]] | None = None) -> tuple[Decimal, Decimal]:
        profile = self.profiles[user_id]
        initial, minimum = money(profile["current_available_balance"]), money(profile["minimum_balance_to_keep"])
        flows, _ = self.forecast(user_id, start, 90, changes)
        for pay_day, amount in payments:
            if start <= pay_day <= start + timedelta(days=90):
                flows[pay_day] -= amount
        balance, low = initial, initial
        for n in range(91):
            balance += flows[start + timedelta(days=n)]
            low = min(low, balance)
        return low, minimum

    def safe(self, user_id: str, start: date, payments: list[tuple[date, Decimal]], changes: list[tuple[str, Decimal, str, Decimal]] | None = None) -> bool:
        low, minimum = self.balances(user_id, start, payments, changes)
        return low + Decimal("0.005") >= minimum

    def amount_safe_today(self, user_id: str, request_date: date, requested: Decimal) -> Decimal:
        low, minimum = self.balances(user_id, request_date, [])
        return max(ZERO, min(requested, (low - minimum).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)))

    def first_safe_full_date(self, user_id: str, request_date: date, requested: Decimal) -> date | None:
        for offset in range(91):
            candidate = request_date + timedelta(days=offset)
            if self.safe(user_id, request_date, [(candidate, requested)]):
                return candidate
        return None

    def eligible_options(self, request: dict[str, str], profile: dict[str, str]) -> list[tuple[dict[str, str], list[tuple[date, Decimal]]]]:
        considers = split(profile["payment_methods_user_will_consider"])
        permitted_months = int(profile["max_installment_months"]) if profile.get("max_installment_months") else 0
        answer = []
        for opt in self.by_request_options[request["request_id"]]:
            method = opt["payment_method"]
            if method not in considers:
                continue
            count = int(opt["number_of_payments"])
            freq = int(opt["payment_frequency_days"] or 0)
            if method == "installments" and (not permitted_months or count * max(freq, 30) > permitted_months * 31):
                continue
            first, amount = d(opt["first_payment_date"]), money(opt["payment_amount"])
            plan = [(first + timedelta(days=freq * i), amount) for i in range(count)]
            answer.append((opt, plan))
        return answer

    def flexible_changes(self, user_id: str, request_date: date) -> list[tuple[str, Decimal, str, Decimal]]:
        """Candidate changes are real flexible recurring records, ranked by likely monthly saving."""
        profile = self.profiles[user_id]
        stop_cats, reduce_cats = split(profile["expense_categories_user_is_willing_to_stop"]), split(profile["expense_categories_user_is_willing_to_reduce"])
        events = self.relevant_events(user_id, request_date, profile["home_currency"])
        choices = []
        for e in events:
            if e["date"] >= request_date or e["direction"] != "debit":
                continue
            cat, flex = str(e["category"]), str(e["flexibility"])
            if cat in stop_cats and flex in {"stoppable", "reducible_or_stoppable"}:
                choices.append((str(e["id"]), e["amount"], "stop", ZERO, e["date"], cat))
            elif cat in reduce_cats and flex in {"reducible", "reducible_or_stoppable"}:
                choices.append((str(e["id"]), e["amount"], "reduce", e["minimum"], e["date"], cat))
        # A historical stream contains many prior occurrences of the same subscription or
        # category; one current instruction must not "stop" all of those as separate changes.
        newest = {}
        for item in choices:
            key = (item[5], item[2])
            if key not in newest or item[4] > newest[key][4]:
                newest[key] = item
        return sorted((x[:4] for x in newest.values()), key=lambda x: x[1], reverse=True)[:6]

    def plan_changes(self, user_id: str, request_date: date, payments: list[tuple[date, Decimal]]) -> list[str] | None:
        # A conservative implementation: test stopping the eligible recurring commitments first,
        # then reducing a reducible one to its supplied lower bound if present.
        if self.safe(user_id, request_date, payments):
            return []
        candidates = self.flexible_changes(user_id, request_date)
        for take in range(1, min(3, len(candidates)) + 1):
            for picked in itertools.combinations(candidates, take):
                if self.safe(user_id, request_date, payments, list(picked)):
                    return list(picked)
        return None

    def decide(self, request: dict[str, str]) -> dict[str, str]:
        profile = self.profiles[request["user_id"]]
        home, today = profile["home_currency"], d(request["request_date"])
        requested, deadline = money(request["requested_amount"]), d(request["desired_completion_date"])
        safe_today = self.amount_safe_today(request["user_id"], today, requested)
        earliest = self.first_safe_full_date(request["user_id"], today, requested)
        eligible = self.eligible_options(request, profile)

        candidates = []
        for opt, plan in eligible:
            if plan[-1][0] <= deadline and self.safe(request["user_id"], today, plan):
                total = sum((x[1] for x in plan), ZERO)
                candidates.append((0, total, plan[0][0], len(plan), opt["payment_option_id"], opt, plan, []))
            elif plan[-1][0] <= deadline:
                changed = self.plan_changes(request["user_id"], today, plan)
                if changed:
                    total = sum((x[1] for x in plan), ZERO)
                    candidates.append((1, total, plan[0][0], len(plan), opt["payment_option_id"], opt, plan, changed))
        # Partial payment has no seller option, but is still constrained by preferences and deadline.
        if (request["allows_partial_payment"].lower() == "true" and "partial_payment" in split(profile["payment_methods_user_will_consider"])
                and ZERO < safe_today < requested and earliest and earliest <= deadline):
            partial = [(today, safe_today), (earliest, requested - safe_today)]
            if self.safe(request["user_id"], today, partial):
                candidates.append((0, requested, today, 2, "partial", {"payment_method": "partial_payment"}, partial, []))

        if candidates:
            # Official tie-break order after feasibility: no changes, cost, start, fewest payments, id.
            _, _, _, _, _, opt, plan, changes = sorted(candidates, key=lambda x: x[:5])[0]
            method = opt["payment_method"]
            is_full = method == "full_payment" and plan[0][0] == today
            status = "affordable_now" if is_full else "affordable_with_plan"
            plan_text = "|".join(f"{day.isoformat()}:{fmt(amount)}" for day, amount in plan)
            low, minimum = self.balances(request["user_id"], today, plan, changes)
            if method == "full_payment":
                explanation = f"Pay {home} {fmt(requested)} today. This keeps at least {home} {fmt(minimum)} available over the next 90 days."
            elif method == "partial_payment":
                explanation = f"Pay {home} {fmt(plan[0][1])} today and the remaining {home} {fmt(plan[1][1])} on {plan[1][0].strftime('%d %B %Y')}; the minimum balance remains protected."
            else:
                explanation = f"Use {len(plan)} installments of {home} {fmt(plan[0][1])}, starting {plan[0][0].strftime('%d %B %Y')}. This keeps at least {home} {fmt(minimum)} available."
            change_text = "|".join(f"stop:{x[0]}" if x[2] == "stop" else f"reduce_to:{x[0]}:{fmt(x[3])}" for x in changes) or "none"
            if changes:
                explanation = "Adjust flexible spending, then " + explanation[0].lower() + explanation[1:]
            return {"request_id": request["request_id"], "amount_safe_to_pay": fmt(safe_today),
                    "affordability_status": status, "recommended_payment_method": method,
                    "payment_plan": plan_text, "earliest_date_for_full_payment": today.isoformat() if is_full else (earliest.isoformat() if earliest else ""),
                    "spending_changes_needed": change_text, "decision_explanation": explanation}

        # Waiting is an option only for users who accept full payment. It does not need to meet
        # the desired date to be "affordable_later", but is the only safe recommendation when it does.
        if earliest and "full_payment" in split(profile["payment_methods_user_will_consider"]):
            plan = [(earliest, requested)]
            return {"request_id": request["request_id"], "amount_safe_to_pay": fmt(safe_today),
                    "affordability_status": "affordable_later", "recommended_payment_method": "wait",
                    "payment_plan": f"{earliest.isoformat()}:{fmt(requested)}", "earliest_date_for_full_payment": earliest.isoformat(),
                    "spending_changes_needed": "none",
                    "decision_explanation": f"Wait until {earliest.strftime('%d %B %Y')}, then pay {home} {fmt(requested)} in full; paying sooner would put the {home} {fmt(money(profile['minimum_balance_to_keep']))} minimum at risk."}
        return {"request_id": request["request_id"], "amount_safe_to_pay": fmt(safe_today),
                "affordability_status": "not_affordable", "recommended_payment_method": "not_recommended",
                "payment_plan": "none", "earliest_date_for_full_payment": "", "spending_changes_needed": "none",
                "decision_explanation": f"Do not proceed with this payment by {deadline.strftime('%d %B %Y')}. No eligible option keeps the {home} {fmt(money(profile['minimum_balance_to_keep']))} minimum protected."}


def main() -> None:
    agent = Agent()
    requests = read_csv("requests.csv")
    rows = [agent.decide(request) for request in requests]
    with (ROOT / "output.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=OUT_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {len(rows)} predictions to {ROOT / 'output.csv'}")


if __name__ == "__main__":
    main()
